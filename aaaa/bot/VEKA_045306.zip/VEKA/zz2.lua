setDefaultTab("OWN")
macro(400, "Fast HP", function()
if hppercent() <= 80 then
useWith(findItem(7643), player)
end
end)
