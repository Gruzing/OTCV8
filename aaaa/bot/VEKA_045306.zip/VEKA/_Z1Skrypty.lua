
local channelList = {9, 6, 13, 14, 0} 
for _, channel in pairs(channelList) do 
g_game.joinChannel(channel) 
end 
--
local minimap = modules.game_minimap.minimapWidget
local label = minimap.coords
label = label or g_ui.loadUIFromString([[
Label
  id: coords
  color: white
  font: verdana-11px-rounded
  anchors.left: parent.left
  anchors.right: parent.right
  anchors.bottom: parent.bottom
  text-align: center
  margin-right: 3
  margin-left: 3
  text:
]], minimap)

onPlayerPositionChange(function(newPos, oldPos)
  if label and newPos then
    label:setText(newPos.x ..', '..newPos.y..', '..newPos.z)
    label:setColor("white")
  end
end)
--
onTextMessage(function(mode, text) 
if string.find(text, 'task. Wpisz') then 
local creature = string.match(text, "!tasklevel%s+([%a%s']+)") 
if creature then say('!tasklevel ' .. creature) end 
end 
end) 
--
local chName = "Terminal"
local function log(msgColor,...)
  local mod = modules.game_console
  local ch = mod.getTab(chName)
  if not ch then
    mod.addTab(chName,false)
  end
  local msg = ""
  local args = {...}
  local appendSpace = #args > 1
  for i,v in ipairs(args) do
    msg = msg .. tostring(v)
    if appendSpace and i < #args then
      msg = msg .. ' , '
    end
  end
  mod.addTabText(msg,{speakType = 6, color = msgColor},ch)
end

function print(...)
  return log('#9dd1ce',...)
end

function warn(...)
  return log('#FFFF00',...)
end

function error(...)
  return log('#F55E5E',...)
end
--
-- Auto Auto Bless 
local bless = false 
macro(1000, "Auto Bless", function() 
if bless ~= true then 
bless = true 
say("!bless") 
end 
end) 
-- Repair Cyleria/Soft boots
macro(10000, "Repair Cyleria/Soft boots", function() 

if getFeet() == nil then return end 

if getFeet():getId() == 6530 then 

say("!soft") 

elseif getFeet():getId() == 9020 then 

say("!cyleria boots") 

end 

end) 

UI.Separator() 

UI.Label("Skrypty EXP:") 

-- AUTO STAMINA 40H 

macro(10*1000, "Auto stamina (40h)", function() 

local minimalStamina = 60*40 

local item1 = 11719 

local item2 = 3209 

stamina = g_game.getLocalPlayer():getStamina() 

if stamina < minimalStamina then 

local foundItem1 = findItem(item1) 

local foundItem2 = findItem(item2) 

if foundItem1 then 

use(item1) 

elseif foundItem2 then 

use(item2) 

end 

end 

end) 

-- AUTO EXP POTION 

macro(1000, "Auto Exp Potion", function() 

local item1 = 11720 

local item2 = 7440 

local Mp = 95 

if not isInPz() then 

if manapercent() < Mp then 

delay(20000) 

local foundItem1 = findItem(item1) 

local foundItem2 = findItem(item2) 

if foundItem1 then 

return use(item1) 

elseif foundItem2 then 

return use(item2) 

end 

end 

end 

end) 

-- AUTO LORD EXP 

macro(1000, "Auto Lord Exp", function() 

local item1 = 11721 

local item2 = 3594 

local Mp = 95 

if not isInPz() then 

if manapercent() < Mp then 

delay(20000) 

local foundItem1 = findItem(item1) 

local foundItem2 = findItem(item2) 

if foundItem1 then 

return use(item1) 

elseif foundItem2 then 

return use(item2) 

end 

end 

end 

end) 

UI.Label("Inne:") 

-- Mikstura zycia 

macro(1000, "Mikstura zycia (50% HP)", function() 

if not isInPz() and hppercent() < 50 and not hasPartyBuff() then 

for _, container in pairs(g_game.getContainers()) do 

for __, item in ipairs(container:getItems()) do 

if item:getId() == 7439 then 

return g_game.use(item) 

end 

end 

end 

end 

end) 

-- EXETA RES 

local spell = "exeta res" 

local hpThreshold = 70 

local waitT = 1700 

macro(1000, "Auto exeta res > 70% HP", function() 

local iloscHp = hppercent() 

if iloscHp > hpThreshold then 

say(spell) 

delay(waitT) 

end 

end) 

-- Spam spell 

macro(700, "Spam Targeted", function() 

if not g_game.isAttacking() then return end 

say(storage.spamTarget) 

end) 

addTextEdit("Spam Target", storage.spamTarget or "inception", function (widget, text) 

storage.spamTarget = text 

end) 

macro(600, "Spam Aoe", function() 

say(storage.spamAoe) 

end) 

addTextEdit("Spam Aoe", storage.spamAoe or "ultimate power", function (widget, text) 

storage.spamAoe = text 

end) 

-- Auto select channel 

UI.Label('Zaznaczanie kanalu:') 

UI.TextEdit(storage.selectChannel or "1", function(widget, text) 

storage.selectChannel = text 

end) 

macro(750, "Select Channel", function() 

local channels = g_ui.getRootWidget():recursiveGetChildById("channels") 

local widget = channels:getParent() 

local submit = widget:recursiveGetChildById("submitButton") 

if #channels:getChildren() > 0 then 

channels:focusChild(channels:getChildByIndex(storage.selectChannel)) 

submit:onClick() 

end 

end) 

